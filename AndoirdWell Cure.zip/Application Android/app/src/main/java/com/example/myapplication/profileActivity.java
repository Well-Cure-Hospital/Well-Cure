package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class profileActivity extends AppCompatActivity {

    private TextView name, mobile, email, password;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        name = findViewById(R.id.uname);
        mobile = findViewById(R.id.umobile);
        email = findViewById(R.id.uemail);
        password = findViewById(R.id.upassword);
    }
}
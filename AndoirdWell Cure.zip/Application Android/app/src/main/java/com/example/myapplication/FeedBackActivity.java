package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FeedBackActivity extends AppCompatActivity {

    EditText ed1, ed2;

    Button feedbtn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);

        feedbtn = findViewById(R.id.buttonFeed);
        ed1 = findViewById(R.id.editfeedUsername);
        ed2 = findViewById(R.id.editFeedMultiLine2);

        feedbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(FeedBackActivity.this, "Feedback Submitted", Toast.LENGTH_SHORT).show();
                String n = ed1.getText().toString();
                String m = ed2.getText().toString();
//                startActivity(new Intent(FeedBackActivity.this, FeedbackActivity2.class));

                Intent i = new Intent(FeedBackActivity.this, FeedbackActivity2.class);
                i.putExtra("username", n);
                i.putExtra("description", m);

                startActivity(i);


//                String mu = ed1.getText().toString();
//                String mm = ed2.getText().toString();
//                String mt = ed3.getText().toString();
//                Toast.makeText(MedicalActivity.this, "Order Placed", Toast.LENGTH_SHORT).show();
//                startActivity(new Intent(MedicalActivity.this, MedicalActivity2.class));
//
//
//                Intent i = new Intent(MedicalActivity.this, MedicalActivity2.class);
//                i.putExtra("username", mu);
//                i.putExtra("mediname", mm);
//                i.putExtra("description", mt);
//
//                startActivity(i);

            }
        });
    }
}
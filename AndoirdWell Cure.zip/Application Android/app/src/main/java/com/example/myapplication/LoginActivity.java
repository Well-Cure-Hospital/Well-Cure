package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText editUsername, editPassword;
    Button btn, btnLogin;
    TextView tv;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btn = findViewById(R.id.buttonLogin);
        tv = findViewById(R.id.textClickHere);
        btnLogin = findViewById(R.id.buttonLogin);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();
                Database db = new Database(getApplicationContext(), "Well_Cure", null, 1);

                if (username.length() == 0 || password.length() == 0){
                    Toast.makeText(getApplicationContext(), "Details are Empty", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (db.login(username, password) == 1){
                        Toast.makeText(getApplicationContext(), "Login Sussessfully", Toast.LENGTH_SHORT).show();
                        SharedPreferences sharedPreferences = getSharedPreferences("SharedPreference", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("username", username);     // to save our data with key values.
                        editor.apply();

                        startActivity(new Intent(LoginActivity.this, PatientActivity.class));

                    }
                    else {
                        Toast.makeText(LoginActivity.this, "Invalid User", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });

//        btnLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String username = editUsername.getText().toString();
//
//                if (username.length() == 5){
//                    startActivity(new Intent(LoginActivity.this, PatientActivity.class));
//                } else if (username.length() == 8) {
//                        startActivity(new Intent(LoginActivity.this, DoctorActivity.class));
//                }
//                else if (username.length() == 3){
//                        startActivity(new Intent(LoginActivity.this, AdminActivity.class));
//                }
//                else {
//                    editUsername.setError("Invalid Username and Password !!");
//                }
//            }
//        });


    }
}
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ServicesActivity2 extends AppCompatActivity {

    public static final String NAME = "NAME";
    public static final String DESC = "DESCRIPTION";

    TextView nameText, reqtext;
    Button btnser;


    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services2);
        nameText = findViewById(R.id.textSERNAME);
        reqtext = findViewById(R.id.textSERESC);
        btnser = findViewById(R.id.buttonSER);


        String username = getIntent().getStringExtra("nameUser");
        String desc = getIntent().getStringExtra("description");


        nameText.setText("NAME :- " + username);
        reqtext.setText("Your Request is :-\n\n" + desc);

        btnser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ServicesActivity2.this, PatientActivity.class));
            }
        });
    }
}
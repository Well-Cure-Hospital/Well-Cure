package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class DoctorDetailsActivity extends AppCompatActivity {

    private String[][] doctor_detail1 = {
            {"Doctor Name : Dhanraj Jadhav", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No : 9876543210","600"},
            {"Doctor Name : Prasad Pawar", "Hospital Address : Nigdi", "Exp : 15yrs", "Mobile No : 8766433211","900"},
            {"Doctor Name : Swapnil Kale", "Hospital Address : Chinchwad", "Exp : 8yrs", "Mobile No : 9212173314","300"},
            {"Doctor Name : Pragati Khedkar", "Hospital Address : Hinjawadi", "Exp : 6yrs", "Mobile No : 9087654321","500"},
            {"Doctor Name : Ajay Nagar", "Hospital Address : Wakad", "Exp : 7yrs", "Mobile No : 9988765432","800"}
    };


    private String[][] doctor_detail2 = {
            {"Doctor Name : Pratik Gupta", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No : 9876543210","600"},
            {"Doctor Name : Sachin Meshram", "Hospital Address : Nigdi", "Exp : 15yrs", "Mobile No : 8766433211","900"},
            {"Doctor Name : Kiran Ramteke", "Hospital Address : Chinchwad", "Exp : 8yrs", "Mobile No : 9212173314","300"},
            {"Doctor Name : Himanshu Jhadhav", "Hospital Address : Hinjawadi", "Exp : 6yrs", "Mobile No : 9087654321","500"},
            {"Doctor Name : Yash Pandey", "Hospital Address : Wakad", "Exp : 7yrs", "Mobile No : 9988765432","800"}
    };


    private String[][] doctor_detail3 = {
            {"Doctor Name : Vipin Rao", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No : 9876543210","600"},
            {"Doctor Name : Aniket Pawar", "Hospital Address : Nigdi", "Exp : 15yrs", "Mobile No : 8766433211","900"},
            {"Doctor Name : Aditya sinha", "Hospital Address : Chinchwad", "Exp : 8yrs", "Mobile No : 9212173314","300"},
            {"Doctor Name : Ankit Sinha", "Hospital Address : Hinjawadi", "Exp : 6yrs", "Mobile No : 9087654321","500"},
            {"Doctor Name : Chirag Ramteke", "Hospital Address : Wakad", "Exp : 7yrs", "Mobile No : 9988765432","800"}
    };

    private String[][] doctor_detail4 = {
            {"Doctor Name : Anup Sarode", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No : 9876543210","600"},
            {"Doctor Name : Akansha Ghorse", "Hospital Address : Nigdi", "Exp : 15yrs", "Mobile No : 8766433211","900"},
            {"Doctor Name : Sagar Sonwane", "Hospital Address : Chinchwad", "Exp : 8yrs", "Mobile No : 9212173314","300"},
            {"Doctor Name : Dhurvesh Ramteke", "Hospital Address : Hinjawadi", "Exp : 6yrs", "Mobile No : 9087654321","500"},
            {"Doctor Name : Noor Siddique", "Hospital Address : Wakad", "Exp : 7yrs", "Mobile No : 9988765432","800"}
    };

    private String[][] doctor_detail5 = {
            {"Doctor Name : Hussian Bhati", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No : 9876543210","600"},
            {"Doctor Name : garekar Meshram", "Hospital Address : Nigdi", "Exp : 15yrs", "Mobile No : 8766433211","900"},
            {"Doctor Name : Ankita Choudhary", "Hospital Address : Chinchwad", "Exp : 8yrs", "Mobile No : 9212173314","300"},
            {"Doctor Name : Sujata Dhote", "Hospital Address : Hinjawadi", "Exp : 6yrs", "Mobile No : 9087654321","500"},
            {"Doctor Name : Jatin Vishkarma", "Hospital Address : Wakad", "Exp : 7yrs", "Mobile No : 9988765432","800"}
    };


    private String[][] doctor_detail6 = {
            {"Doctor Name : Bhuvan Bam", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No : 9876543210","600"},
            {"Doctor Name : Ashish Chanchalani", "Hospital Address : Nigdi", "Exp : 15yrs", "Mobile No : 8766433211","900"},
            {"Doctor Name : Ajay Nagar", "Hospital Address : Chinchwad", "Exp : 8yrs", "Mobile No : 9212173314","300"},
            {"Doctor Name : Prajakta Sane", "Hospital Address : Hinjawadi", "Exp : 6yrs", "Mobile No : 9087654321","500"},
            {"Doctor Name : Tushar Kair", "Hospital Address : Wakad", "Exp : 7yrs", "Mobile No : 9988765432","800"}
    };
    TextView tv;
    String[][] doctor_details = {};
    ArrayList list;
    HashMap<String, String> item;
    SimpleAdapter sa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctordetails);


        tv = findViewById(R.id.textViewDDTitle);
        Intent it = getIntent();
        String title = it.getStringExtra("title");
        tv.setText(title);

        if (title.compareTo("Physician") == 0){
            doctor_details = doctor_detail1;
        } else if (title.compareTo("Dermatologist") == 0) {
            doctor_details = doctor_detail2;
        }
        else if (title.compareTo("Denist") == 0) {
            doctor_details = doctor_detail3;
        }
        else if (title.compareTo("Surgeon") == 0) {
            doctor_details = doctor_detail4;
        }
        else if (title.compareTo("Cardiologist") == 0) {
            doctor_details = doctor_detail5;
        }
        else {
            doctor_details = doctor_detail6;
        }


        list = new ArrayList();
        for (int i = 0; i<doctor_details.length; i++){
            item = new HashMap<String, String>();
            item.put("line1", doctor_details[i][0]);
            item.put("line2", doctor_details[i][1]);
            item.put("line3", doctor_details[i][2]);
            item.put("line4", doctor_details[i][3]);
            item.put("line5", "Course Fee : " + doctor_details[i][4] + " /-");
            list.add( item );
        }
        sa = new SimpleAdapter(this, list,R.layout.multi_line, new String[]{"line1","line2","line3","line4","line5"},
                new int[]{R.id.line_a,R.id.line_b,R.id.line_c,R.id.line_d,R.id.line_e});

        ListView lst = findViewById(R.id.listViewDD);
        lst.setAdapter(sa);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent it = new Intent(DoctorDetailsActivity.this, BookAppointmentActivity.class);
                it.putExtra("text1", title);
                it.putExtra("text2", doctor_details[i][0]);
                it.putExtra("text3", doctor_details[i][1]);
                it.putExtra("text4", doctor_details[i][3]);
                it.putExtra("text5", doctor_details[i][4]);
                startActivity(it);
            }
        });
    }
}
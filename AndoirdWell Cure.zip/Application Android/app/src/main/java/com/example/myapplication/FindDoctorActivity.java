package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class FindDoctorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_doctor);

        CardView physician = findViewById(R.id.cardFDPhysician);
        physician.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FindDoctorActivity.this, DoctorDetailsActivity.class);
                i.putExtra("title", "Physician");
                startActivity(i);
            }
        });


        CardView Dermatologist = findViewById(R.id.cardFDDermatologist);
        Dermatologist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FindDoctorActivity.this, DoctorDetailsActivity.class);
                i.putExtra("title", "Dermatologist");
                startActivity(i);
            }
        });


        CardView Dentist = findViewById(R.id.cardFDDentist);
        Dentist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FindDoctorActivity.this, DoctorDetailsActivity.class);
                i.putExtra("title", "Dentist");
                startActivity(i);
            }
        });


        CardView Surgeon = findViewById(R.id.cardFDSurgeon);
        Surgeon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FindDoctorActivity.this, DoctorDetailsActivity.class);
                i.putExtra("title", "Surgeon");
                startActivity(i);
            }
        });

        CardView Cardiologist = findViewById(R.id.cardFDCardiologist);
        Cardiologist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FindDoctorActivity.this, DoctorDetailsActivity.class);
                i.putExtra("title", "Cardiologist");
                startActivity(i);
            }
        });


        CardView Orthopedic = findViewById(R.id.cardFDOrthopedic);
        Orthopedic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FindDoctorActivity.this, DoctorDetailsActivity.class);
                i.putExtra("title", "Orthopedic");
                startActivity(i);
            }
        });
    }
}
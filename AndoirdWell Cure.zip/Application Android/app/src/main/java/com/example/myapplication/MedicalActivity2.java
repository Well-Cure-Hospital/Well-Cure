package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MedicalActivity2 extends AppCompatActivity {

   TextView nameText, medText, medDesc;

   Button buttonMed;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical2);
        nameText = findViewById(R.id.textMEDINAME);
        medText = findViewById(R.id.textMEDICINENAME);
        medDesc = findViewById(R.id.textMEDIDESC);


        String username = getIntent().getStringExtra("username");
        String medname = getIntent().getStringExtra("mediname");
        String desc = getIntent().getStringExtra("description");


        nameText.setText("Name :- " + username);
        medText.setText("Medicine Name :-" + medname);
        medDesc.setText("Medicine Description :- \n\n"+desc);


        buttonMed = findViewById(R.id.buttonMEDI);


        buttonMed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MedicalActivity2.this, PatientActivity.class));
            }
        });
    }


}
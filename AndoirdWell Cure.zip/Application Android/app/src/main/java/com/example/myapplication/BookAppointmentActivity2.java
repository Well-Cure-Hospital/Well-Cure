package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BookAppointmentActivity2 extends AppCompatActivity {

    EditText ed1, ed2, ed3, ed4;
    TextView t1, t2;
    Button btnapp;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appointment2);

        ed1 = findViewById(R.id.editBookedUsername);
        ed2 = findViewById(R.id.editBookedAddress);
        ed3 = findViewById(R.id.editBookedContact);
        ed4 = findViewById(R.id.editBookedFees);
        t1 = findViewById(R.id.textBookedDate);
        t2 = findViewById(R.id.textBookedTime);
        btnapp = findViewById(R.id.buttonBookedAppointment);


        String boname = getIntent().getStringExtra("bname");
        String baddr = getIntent().getStringExtra("baddress");
        String bcont = getIntent().getStringExtra("bcontact");
        String bfees = getIntent().getStringExtra("bfees");
        String bdate = getIntent().getStringExtra("bdate");
        String btime = getIntent().getStringExtra("btime");

        ed1.setText(boname);
        ed2.setText(baddr);
        ed3.setText(bcont);
        ed4.setText(bfees);
        t1.setText(bdate);
        t2.setText(btime);


        btnapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BookAppointmentActivity2.this, PatientActivity.class));
            }
        });
    }
}
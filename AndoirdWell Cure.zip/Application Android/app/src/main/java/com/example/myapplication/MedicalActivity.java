package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MedicalActivity extends AppCompatActivity {

    EditText ed1, ed2, ed3;


    Button medibtn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical);

        medibtn = findViewById(R.id.buttonMedical);
        ed1 = findViewById(R.id.editMidicineUsername);
        ed2 = findViewById(R.id.editMedicine);
        ed3 = findViewById(R.id.editMedicineMultiLine);

        medibtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mu = ed1.getText().toString();
                String mm = ed2.getText().toString();
                String mt = ed3.getText().toString();
                Toast.makeText(MedicalActivity.this, "Order Placed", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MedicalActivity.this, MedicalActivity2.class));


                Intent i = new Intent(MedicalActivity.this, MedicalActivity2.class);
                i.putExtra("username", mu);
                i.putExtra("mediname", mm);
                i.putExtra("description", mt);

                startActivity(i);

            }
        });
    }
}
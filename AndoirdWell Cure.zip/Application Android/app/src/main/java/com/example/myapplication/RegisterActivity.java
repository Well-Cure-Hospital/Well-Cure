package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;

public class RegisterActivity extends AppCompatActivity {
    String[] roles = {"Patient", "Doctor", "Admin"};
    TextInputLayout name, email;
    EditText etName, etMobile, etEmail, etPassword, etConfirmPassword;
    Button btClear, btRegister;


//    ArrayAdapter<String> adapterRoles;
//    AutoCompleteTextView autoCompleteTextView;

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

//        Assign Variable :-
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etMobile = findViewById(R.id.et_mobile);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirmPassword);
        btClear = findViewById(R.id.bt_clear);
        btRegister = findViewById(R.id.bt_register);


        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().isEmpty() && !s.toString().matches("[a-z A-Z]+")) {
                    name.setError("Only Characters are Allowed");
                } else {
                    name.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        btClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etName.getText().clear();
                etMobile.getText().clear();
                etEmail.getText().clear();
                etPassword.getText().clear();
                etPassword.clearFocus();
                etConfirmPassword.getText().clear();
                etConfirmPassword.clearFocus();
//                autoCompleteTextView.clearFocus();
            }
        });


//        autoCompleteTextView = findViewById(R.id.a);
//        adapterRoles = new ArrayAdapter<String>(this, R.layout.list_item, roles);

//        autoCompleteTextView.setAdapter(adapterRoles);
//        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
//                String roles = adapterView.getItemAtPosition(position).toString();
//                Toast.makeText(RegisterActivity.this, "Role: " + roles, Toast.LENGTH_SHORT).show();
//            }
//        });


        btRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etName.getText().toString();
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String mobile = etMobile.getText().toString();
                String confirmPassword = etConfirmPassword.getText().toString();
//                String roles = autoCompleteTextView.getText().toString();
                Database db = new Database(getApplicationContext(), "Well_Cure", null, 1);


                if (username.length() == 0 || email.length() == 0 || password.length() == 0 || confirmPassword.length() == 0 || mobile.length() == 0) {
                    Toast.makeText(RegisterActivity.this, "Please fill the details", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (password.compareTo(confirmPassword) == 0) {
                        if (isValid(password)){
                            db.register(username, email,password, mobile);
                            Toast.makeText(RegisterActivity.this, "Record Inserted", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                        }
                        else{
                            etPassword.setError("Password must contain at least 8 character, Which contains letter, digit and special symbol");
//                            Toast.makeText(RegisterActivity.this, "Password must contain at least 8 character, Which contains letter, digit and special symbol", Toast.LENGTH_SHORT).show();
                        }

                    }
                    else {
                        Toast.makeText(RegisterActivity.this, "Confirm Password didn't match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

    public static boolean isValid(String passwordhere){
        int f1 = 0, f2 = 0, f3 = 0;
        if (passwordhere.length() < 8){
            return false;
        }
        else {
            for (int p = 0; p < passwordhere.length(); p++){
                if (Character.isLetter(passwordhere.charAt(p))){
                    f1 = 1;
                }
            }
            for (int r = 0; r < passwordhere.length(); r++){
                if (Character.isDigit(passwordhere.charAt(r))){
                    f2 = 1;
                }
            }
            for (int s = 0; s < passwordhere.length(); s++){
                char c = passwordhere.charAt(s);
                if (c>33 && c<=46 || c == 64){
                    f3 = 1;
                }
            }
            if (f1 == 1 && f2 == 1 && f3 == 1)
                return true;
            return false;
        }
    }
}
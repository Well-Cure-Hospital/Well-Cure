//import { BrowserRouter as Routes, Route } from "react-router-dom";
//import { BrowserRouter as  Routes,Route,Link } from "react-router-dom";
import { BrowserRouter , Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
//import Desc from "./page/Desc";
import Pagenotfound from "./pages/Pagenotfound";
import Detail from "./pages/Detail";
import Appo from "./pages/Appo";
import AppoDetails from "./pages/AppoDetails";
function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/deatil" element={<Detail />} />
          <Route path="/appo" element={<Appo />} />
          <Route path="/appod" element={<AppoDetails />} />
          {/* <Route path="/desc" element={<Desc/>} /> */}
          <Route path="*" element={<Pagenotfound />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
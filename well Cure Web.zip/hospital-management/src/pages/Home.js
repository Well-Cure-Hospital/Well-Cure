import React from "react";
import Layout from "./../components/Layout/Layout";
import { Link } from "react-router-dom";
import logo from "../images/back2.jpg";
import "../styles/HomeStyles.css";

const Home = () => {
  return (
    <Layout>
      <div className="home" style={{ backgroundImage: `url(${logo})` }}>
        <div className="headerContainer">
          <h1>Well Cure </h1>
          <p>Best Appliction In India</p>
          <Link to="/deatil">
            <button>See detials</button>
          </Link>
        </div>
      </div>
    </Layout>
  );
};

export default Home;

import React,{ useState} from 'react'
import { Container,Row,Col,Form,Button,Alert ,Card} from 'react-bootstrap';
import {Link,useNavigate} from "react-router-dom";
import { toast } from 'react-toastify';
import Layout from "../components/Layout/Layout";

// fetch the url
function Appo() {
 const navigate=useNavigate();
 const [fname, setFName]=useState("");
 const [lname, setLName]=useState("");
 const [email, setEmail]=useState("");
 const [password, setPassword]=useState("");
 const [address, setAddress]=useState("");
 const [mobail, setMobail]=useState("");
 const [date, setDate]=useState("MM/DD/YYYY");

//  Tostify function for alert
const notifyError=(msg)=>toast.error(msg);
const notifySuccess=(msg)=>toast.success(msg);

// use Regex for valid email or password 

const passwordRegex=/(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9])(?=.{8,})/;


//  const postData=()=>{
// //  check Email
// if(!passwordRegex.test(password)){
//   notifyError("Please Enter Strong Password, one lowercase letters, one uppercase letters, alphanumeric characters, one Special character #,@,?");
//   return

// }


   // console.log({name,email,userName,password })

   // sending data to server we using fetch
//    fetch("http://localhost:4444/user", { 
//       method: "post",
//       headers: {
//         "Content-Type": "application/json"
//       },
//       body: JSON.stringify({
//         fname: fname,
//         lname: lname,
//         email: email,
//         password: password,
//         address:address,
//         mobail:mobail,
//         date:date
//       })
//     }).then(res =>{
//       // console.log(res.status)
//       // console.log(res.ok)
//       return  res.json()
//     })//return response callback function 
//       .then(data => {
//         if (data.error) {
//           notifyError(data.error) //show alert
//         } else {
//           notifySuccess(data.message)
//           navigate("/login")
//         }
//         console.log(data)
//       })
//  }

   
  return (
    <Layout>
    <Container>
            <Row className="justify-content-center">
                <Col md={6}>
                    <Card>
                        <Card.Body>
                            <div className="py-5 text-center">
                                <h1 className="display-3">Appimonet</h1>
                            </div>
                            {/* {error && <Alert variant="danger">{error}</Alert>} */}
                            {/* <Form > //Card.Body>onSubmit={handleSubmit} */}
                            <Form >
                                <Form.Group controlId=" Name">
                                    <Form.Label>Name</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter  Name"
                                        name="userName"
                                        // value={formData.userName}
                                        // onChange={handleChange}
                                    />
                                </Form.Group>
                                <Form.Group controlId="email">
                                    <Form.Label>Email</Form.Label>
                                    <Form.Control
                                        type="email"
                                        placeholder="Enter email"
                                        name="email"
                                        // value={formData.email}
                                        // onChange={handleChange}
                                    />
                                </Form.Group>
                                <Form.Group controlId="password">
                                    <Form.Label>Password</Form.Label>
                                    <Form.Control
                                        type="password"
                                        placeholder="Enter password"
                                        name="password"
                                        // value={formData.password}
                                        // onChange={handleChange}
                                    />
                                </Form.Group>
                                <Form.Group controlId="occupation">
                                    <Form.Label>Occupation</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter occupation"
                                        name="occupation"
                                        // value={formData.occupation}
                                        // onChange={handleChange}
                                    />
                                </Form.Group>
                                <Form.Group controlId="hospitalName">
                                    <Form.Label>Hospital Name</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter hospital name"
                                        name="hospitalName"
                                        // value={formData.hospitalName}
                                        // onChange={handleChange}
                                    />
                                </Form.Group>
                                <Form.Group controlId="phoneNumber">
                                    <Form.Label>Phone Number</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter phone number"
                                        name="phoneNumber"
                                        // value={formData.phoneNumber}
                                        // onChange={handleChange}
                                    />
                                </Form.Group>
                                <Form.Group controlId="address">
                                    <Form.Label>Address</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter address"
                                        name="address"
                                        // value={formData.address}
                                        // onChange={handleChange}
                                    />
                                </Form.Group>
                                <div>
                                    
                                </div>
                                <Button variant="primary" type="submit" block>
                                    Appimonet
                                </Button>
                                <div>

                                </div>
                                <center>
                                <div className='form2' >
            Already have an Appimonet ? 
            <br></br>
            <Link to='/appod'>
            <span style={{color: 'blue', cursor: 'pointer'}} >Appimonet detail.</span>
            </Link>
            </div></center>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            
    </Container></Layout>
  )
}

export default Appo
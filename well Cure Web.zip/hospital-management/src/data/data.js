import image1 from "../images/back2.jpg";
import image2  from "../images/dermatologist.jpeg";
import image3 from "../images/dietician.jpg";
import image4 from "../images/back1.jpg";
import image5 from "../images/back2.jpg";
import image6 from "../images/background.jpg";

export const MenuList1 = [
  {
    name: "find doctor",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
     image: image1,
    // price: 8000,
    
  },
  {
    name: "Medicines",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
  image: image3,
    price: 6500,
  },
  {
    name: "Lab Test",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image: image4,
    price: 1800,
  },
  {
    name: "General check",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image:image5,
    price: 48000,
  },
  
];

import image1 from "../images/dentist.jpg";
import image2  from "../images/dermatologist.jpeg";
import image3 from "../images/dietician.jpg";
import image4 from "../images/family_physicians.jpg";
import image5 from "../images/back2.jpg";
import image6 from "../images/background.jpg";

export const MenuList2 = [
  {
    name: "dentist",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
     image: image1,
    // price: 8000,
    
  },
  {
    name: "dermatologist",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
  image: image3,
    price: 6500,
  },
  {
    name: "dietician.",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image: image4,
    price: 1800,
  },
  {
    name: "Physician",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image:image5,
    price: 48000,
  },
  
];
